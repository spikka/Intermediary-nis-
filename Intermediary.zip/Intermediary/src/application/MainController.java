package application;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import IntermediaryDB.Agent;
import IntermediaryDB.AgentDao;
import IntermediaryDB.Customer;
import IntermediaryDB.CustomerDao;
import IntermediaryDB.Deal;
import IntermediaryDB.DealDao;
import IntermediaryDB.Organization;
import IntermediaryDB.OrganizationDao;
import IntermediaryDB.Person;
import IntermediaryDB.PersonDao;
import IntermediaryDB.Seller;
import IntermediaryDB.SellerDao;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Control;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class MainController {
   private ResourceBundle bundle;
   private Stage window;
   private FXMLLoader loader;
   private Connection connection;
   private TblTypes currentTable; 
   private Integer colIndex = -1; // Для определениия по какой колонке фильтровать
   
   private DealDao dealDao;
   private AgentDao agentDao;
   private SellerDao sellerDao;
   private CustomerDao customerDao;
   private PersonDao personDao;
   private OrganizationDao organizationDao;
   private ObservableList<Object> data;
   private ObservableList<String> chList;
   
   @FXML private Button tvbAdd;
   @FXML private Button tvbEdit;
   @FXML private Button tvbDel;
   @FXML private TableView tableView;
   @FXML private ChoiceBox<String> choiceBox;   
   @FXML private TextField searchField;
   
	public MainController(Stage window, ResourceBundle bundle, FXMLLoader l, Connection c) {
	   this.window = window;
	   this.bundle = bundle;
	   this.loader = l;
	   this.connection = c;
	   this.currentTable = TblTypes.tblDeals;
	   //this.choiceBox = new ChoiceBox<String>();
	   //Agent currentAgent = getAgent();
	   //int a = currentAgent.getId();
	}
	
	public void initialize() {
	   tvbAdd.setGraphic(new ImageView(getClass().getResource("add.png").toString()));
	   tvbEdit.setGraphic(new ImageView(getClass().getResource("edit.png").toString()));
	   tvbDel.setGraphic(new ImageView(getClass().getResource("del.png").toString()));
	   choiceBox = (ChoiceBox<String>) loader.getNamespace().get("choiceBox");
	   showData(currentTable);
	   //Agent currentAgent = getAgent();
      //int a = currentAgent.getId();
	}
	
	public void showData(TblTypes tbl) {
	   tableView.getItems().clear();
      tableView.getColumns().clear();
	   switch (tbl) {
         case tblPersons:
            TableColumn<Person, Integer> idPersonColumn = new TableColumn<Person, Integer>(bundle.getString("tcIdColumn"));
            idPersonColumn.setCellValueFactory(item -> item.getValue().idProperty().asObject());
            idPersonColumn.setPrefWidth(50);
            idPersonColumn.setMinWidth(50);
            idPersonColumn.setMaxWidth(50);
            TableColumn<Person, String> surnameColumn = new TableColumn<Person, String>(bundle.getString("tcSurnameColumn"));
            surnameColumn.setCellValueFactory(item -> item.getValue().surnameProperty());
            TableColumn<Person, String> nameColumn = new TableColumn<Person, String>(bundle.getString("tcNameColumn"));
            nameColumn.setCellValueFactory(item -> item.getValue().nameProperty());
            TableColumn<Person, String> patronColumn = new TableColumn<Person, String>(bundle.getString("tcPatronColumn"));
            patronColumn.setCellValueFactory(item -> item.getValue().patronProperty());
            tableView.getColumns().addAll(idPersonColumn, surnameColumn, nameColumn, patronColumn);
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            chList = FXCollections.observableArrayList(bundle.getString("tcNoFilter"), 
                        bundle.getString("tcIdColumn"),
                        bundle.getString("tcSurnameColumn"),
                        bundle.getString("tcNameColumn"),
                        bundle.getString("tcPatronColumn")
                        );
            choiceBox.setItems(chList);
            choiceBox.getSelectionModel().select(0);
            this.colIndex = 0;
            // Получаем данные
            personDao = new PersonDao(connection);
            data = FXCollections.observableArrayList(personDao.findAll());
            tableView.setItems(data);
            this.window.setTitle("Intermediary - "+ bundle.getString("referencesPersons"));
            this.currentTable = TblTypes.tblPersons;
            break;
         case tblOrganizations:
            TableColumn<Organization, Integer> idOrganizationColumn = new TableColumn<Organization, Integer>(bundle.getString("tcIdColumn"));
            idOrganizationColumn.setCellValueFactory(item -> item.getValue().idProperty().asObject());
            idOrganizationColumn.setMinWidth(50);
            idOrganizationColumn.setMaxWidth(50);
            TableColumn<Organization, String> nameOrgColumn = new TableColumn<Organization, String>(bundle.getString("tcOrgnameColumn"));
            nameOrgColumn.setCellValueFactory(item -> item.getValue().nameProperty());
            nameOrgColumn.setCellFactory(tc -> {
               TableCell<Organization, String> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(nameOrgColumn.widthProperty());
               text.textProperty().bind(cell.itemProperty());
               return cell ;
            });
            TableColumn<Organization, String> innColumn = new TableColumn<Organization, String>(bundle.getString("tcInnColumn"));
            innColumn.setCellValueFactory(item -> item.getValue().innProperty());
            innColumn.setMinWidth(96);
            innColumn.setMaxWidth(96);
            TableColumn<Organization, String> ogrnColumn = new TableColumn<Organization, String>(bundle.getString("tcOgrnColumn"));
            ogrnColumn.setCellValueFactory(item -> item.getValue().ogrnProperty());
            ogrnColumn.setMinWidth(100);
            ogrnColumn.setMaxWidth(100);
            TableColumn<Organization, String> kppColumn = new TableColumn<Organization, String>(bundle.getString("tcKppColumn"));
            kppColumn.setCellValueFactory(item -> item.getValue().kppProperty());
            kppColumn.setMinWidth(75);
            kppColumn.setMaxWidth(75);
            TableColumn<Organization, String> okpoColumn = new TableColumn<Organization, String>(bundle.getString("tcOkpoColumn"));
            okpoColumn.setCellValueFactory(item -> item.getValue().okpoProperty());
            okpoColumn.setMinWidth(80);
            okpoColumn.setMaxWidth(80);
            TableColumn<Organization, String> addrColumn = new TableColumn<Organization, String>(bundle.getString("tcAddrColumn"));
            addrColumn.setCellValueFactory(item -> item.getValue().addrProperty());
            addrColumn.setCellFactory(tc -> {
               TableCell<Organization, String> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(addrColumn.widthProperty());
               text.textProperty().bind(cell.itemProperty());
               return cell ;
            });
            addrColumn.setPrefWidth(150);
            addrColumn.setMaxWidth(250);
            tableView.getColumns().addAll(idOrganizationColumn, nameOrgColumn, 
                  innColumn, ogrnColumn, kppColumn, okpoColumn, addrColumn);
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            chList = FXCollections.observableArrayList(bundle.getString("tcNoFilter"), 
                        bundle.getString("tcIdColumn"),
                        bundle.getString("tcOrgnameColumn"),
                        bundle.getString("tcInnColumn"),
                        bundle.getString("tcOgrnColumn"),
                        bundle.getString("tcKppColumn"),
                        bundle.getString("tcOkpoColumn"),
                        bundle.getString("tcAddrColumn")
                        );
            choiceBox.setItems(chList);
            choiceBox.getSelectionModel().select(0);
            this.colIndex = 0;
            // Получаем данные
            organizationDao = new OrganizationDao(connection);
            data = FXCollections.observableArrayList(organizationDao.findAll());
            tableView.setItems(data);
            this.window.setTitle("Intermediary - "+ bundle.getString("referencesOrganizations"));
            this.currentTable = TblTypes.tblOrganizations;
            break;
	      case tblCustomers:
	         TableColumn<Customer, Integer> idCustomerColumn = new TableColumn<Customer, Integer>(bundle.getString("tcIdColumn"));
	         idCustomerColumn.setCellValueFactory(item -> item.getValue().idProperty().asObject());
	         idCustomerColumn.setPrefWidth(50);
	         idCustomerColumn.setMinWidth(50);
	         idCustomerColumn.setMaxWidth(50);
            TableColumn<Customer, String> customerStringColumn = new TableColumn<Customer, String>(bundle.getString("tcCustomerColumn"));
            customerStringColumn.setCellValueFactory(item -> new SimpleStringProperty(item.getValue().toString()));
            customerStringColumn.setCellFactory(tc -> {
               TableCell<Customer, String> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(customerStringColumn.widthProperty());
               text.textProperty().bind(cell.itemProperty());
               return cell ;
            });
            tableView.getColumns().addAll(idCustomerColumn, customerStringColumn);
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            chList = FXCollections.observableArrayList(bundle.getString("tcNoFilter"), 
                        bundle.getString("tcIdColumn"),
                        bundle.getString("tcCustomerColumn")
                        );
            choiceBox.setItems(chList);
            choiceBox.getSelectionModel().select(0);
            this.colIndex = 0;
            // Получаем данные
            customerDao = new CustomerDao(connection);
            data = FXCollections.observableArrayList(customerDao.findAll());
            tableView.setItems(data);
            this.window.setTitle("Intermediary - "+ bundle.getString("tablesCustomers"));
            this.currentTable = TblTypes.tblCustomers;
            break;
	      case tblSellers:
	         TableColumn<Seller, Integer> idSellerColumn = new TableColumn<Seller, Integer>(bundle.getString("tcIdColumn"));
            idSellerColumn.setCellValueFactory(item -> item.getValue().idProperty().asObject());
            idSellerColumn.setPrefWidth(50);
            idSellerColumn.setMinWidth(50);
            idSellerColumn.setMaxWidth(50);
            TableColumn<Seller, String> sellerStringColumn = new TableColumn<Seller, String>(bundle.getString("tcSellerColumn"));
            sellerStringColumn.setCellValueFactory(item -> new SimpleStringProperty(item.getValue().toString()));
            sellerStringColumn.setCellFactory(tc -> {
               TableCell<Seller, String> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(sellerStringColumn.widthProperty());
               text.textProperty().bind(cell.itemProperty());
               return cell ;
            });
            tableView.getColumns().addAll(idSellerColumn, sellerStringColumn);
               tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
               chList = FXCollections.observableArrayList(bundle.getString("tcNoFilter"), 
                           bundle.getString("tcIdColumn"),
                           bundle.getString("tcSellerColumn")
                           );
               choiceBox.setItems(chList);
               choiceBox.getSelectionModel().select(0);
               this.colIndex = 0;
               // Получаем данные
               sellerDao = new SellerDao(connection);
               data = FXCollections.observableArrayList(sellerDao.findAll());
               tableView.setItems(data);
               this.window.setTitle("Intermediary - "+ bundle.getString("tablesSellers"));
               this.currentTable = TblTypes.tblSellers;
	         break;
	      default:
	         TableColumn<Deal, Integer> idColumn = new TableColumn<Deal, Integer>(bundle.getString("tcIdColumn"));
	         idColumn.setCellValueFactory(item -> item.getValue().idProperty().asObject());
	         TableColumn<Deal, Agent> agentColumn = new TableColumn<Deal, Agent>(bundle.getString("tcAgentColumn"));
            agentColumn.setCellValueFactory(item -> item.getValue().agentProperty());
            agentColumn.setCellFactory(tc -> {
               TableCell<Deal, Agent> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(agentColumn.widthProperty());
               //text.textProperty().bind(cell.itemProperty().asString());
               StringBinding sb = new StringBinding() {
                  { super.bind(cell.itemProperty()); }
                  
                  @Override
                  protected String computeValue() {
                      final Object value = cell.itemProperty().getValue();
                      return (value == null)? "" : value.toString();
                  }
               };
               text.textProperty().bind(sb);
               return cell ;
            });
            agentColumn.setPrefWidth(200);
            //agentColumn.setMaxWidth(250);
            if ((new AgentDao(connection)).findAll().size() > 1)
               agentColumn.setVisible(true);
            else
               agentColumn.setVisible(false);
            
            TableColumn<Deal, Seller> sellerColumn = new TableColumn<Deal, Seller>(bundle.getString("tcSellerColumn"));
            sellerColumn.setCellValueFactory(item -> item.getValue().sellerProperty());
            sellerColumn.setPrefWidth(200);
            //sellerColumn.setMaxWidth(250);
            
            sellerColumn.setCellFactory(tc -> {
               TableCell<Deal, Seller> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(sellerColumn.widthProperty());
               //text.textProperty().bind(cell.itemProperty().asString());
               StringBinding sb = new StringBinding() {
                  { super.bind(cell.itemProperty()); }
                  
                  @Override
                  protected String computeValue() {
                      final Object value = cell.itemProperty().getValue();
                      return (value == null)? "" : value.toString();
                  }
               };
               text.textProperty().bind(sb);
               return cell ;
            });
            //sellerColumn.setVisible(false);
            
            TableColumn<Deal, Customer> customerColumn = new TableColumn<Deal, Customer>(bundle.getString("tcCustomerColumn"));
            customerColumn.setCellValueFactory(item -> item.getValue().customerProperty());
            customerColumn.setCellFactory(tc -> {
               TableCell<Deal, Customer> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(customerColumn.widthProperty());
               //text.textProperty().bind(cell.itemProperty().asString());
               StringBinding sb = new StringBinding() {
                  { super.bind(cell.itemProperty()); }
                  
                  @Override
                  protected String computeValue() {
                      final Object value = cell.itemProperty().getValue();
                      return (value == null)? "" : value.toString();
                  }
               };
               text.textProperty().bind(sb);
               return cell ;
            });
            customerColumn.setPrefWidth(200);
            //customerColumn.setMaxWidth(250);
                        
            TableColumn<Deal, String> bargainColumn = new TableColumn<Deal, String>(bundle.getString("tcBargainColumn"));
            bargainColumn.setCellValueFactory(item -> item.getValue().bargainProperty());
            bargainColumn.setCellFactory(tc -> {
               TableCell<Deal, String> cell = new TableCell<>();
               Text text = new Text();
               cell.setGraphic(text);
               cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
               text.wrappingWidthProperty().bind(bargainColumn.widthProperty());
               text.textProperty().bind(cell.itemProperty());
               return cell ;
            });
            bargainColumn.setPrefWidth(200);
            
            TableColumn<Deal, Date> date_dColumn = new TableColumn<Deal, Date>(bundle.getString("tcDatedColumn"));
            date_dColumn.setCellValueFactory(item -> item.getValue().date_dProperty());
            TableColumn<Deal, BigDecimal> sum_dColumn = new TableColumn<Deal, BigDecimal>(bundle.getString("tcSumdColumn"));
            sum_dColumn.setCellValueFactory(item -> item.getValue().sum_dProperty());
            TableColumn<Deal, BigDecimal> profitColumn = new TableColumn<Deal, BigDecimal>(bundle.getString("tcProfitColumn"));
            profitColumn.setCellValueFactory(item -> item.getValue().profitProperty());
                        
            tableView.getColumns().addAll(idColumn, agentColumn, sellerColumn, 
               customerColumn, bargainColumn, date_dColumn, sum_dColumn, profitColumn);
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            chList = FXCollections.observableArrayList(bundle.getString("tcNoFilter"), 
                        bundle.getString("tcIdColumn"),
                        bundle.getString("tcAgentColumn"),
                        bundle.getString("tcSellerColumn"),
                        bundle.getString("tcCustomerColumn"),
                        bundle.getString("tcBargainColumn"),
                        bundle.getString("tcDatedColumn"),
                        bundle.getString("tcSumdColumn"),
                        bundle.getString("tcProfitColumn")
                        );
            choiceBox.setItems(chList);
            choiceBox.setOnAction(event -> this.colIndex = choiceBox
                                       .getSelectionModel().getSelectedIndex());
            choiceBox.getSelectionModel().select(0);
            this.colIndex = 0;
            // Получаем данные
            dealDao = new DealDao(connection);
            data = FXCollections.observableArrayList(dealDao.findAll());
            tableView.setItems(data);
            this.window.setTitle("Intermediary - "+ bundle.getString("tablesDeals"));
            this.currentTable = TblTypes.tblDeals;
            break;
	   }
	}
	
	//===========Поисковые обработчики===============
	/*
	 private <T> void setupSearchFilter(TextField textField, TableColumn<Person, T> column) {
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            tableView.getItems().clear();
            tableView.getItems().addAll(data.filtered(person ->
                String.valueOf(column.getCellData(person)).toLowerCase()
                        .contains(newValue.toLowerCase())
            ));
        });
    }
	 */
	
	//===============================
	public void filterData(String sSeacch, TblTypes table, Integer colIdx) {
	   if (sSeacch == null || sSeacch.isEmpty() || sSeacch == "") {
	      this.searchField.clear();
	      this.tableView.setItems(data);
	      this.tableView.getSelectionModel().selectFirst();
	   }
	   else {
	      switch (table) {
	         case tblDeals:
	            ObservableList<Deal> filteredDeals = FXCollections.observableArrayList();
	            for(Deal item : (ObservableList<Deal>)this.tableView.getItems()){
	               boolean result = false;
                  switch (colIdx) {
                  case 1: 
                     result = String.valueOf(item.getId()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 2: 
                     result = String.valueOf(item.getAgent().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 3: 
                     result = String.valueOf(item.getSeller().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 4: 
                     result = String.valueOf(item.getCustomer().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 5: 
                     result = String.valueOf(item.getBargain()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 6: 
                     result = String.valueOf(item.getDate_d().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 7: 
                     result = String.valueOf(item.getSum_d().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  case 8: 
                     result = String.valueOf(item.getProfit().toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                     break;
                  default:
                     String s = String.valueOf(item.getId()).toLowerCase() +
                           String.valueOf(item.getAgent().toString()).toLowerCase() +
                           String.valueOf(item.getSeller().toString()).toLowerCase() +
                           String.valueOf(item.getCustomer().toString()).toLowerCase() +
                           String.valueOf(item.getBargain()).toLowerCase() +
                           String.valueOf(item.getDate_d().toString()).toLowerCase() +
                           String.valueOf(item.getSum_d().toString()).toLowerCase() +
                           String.valueOf(item.getProfit().toString()).toLowerCase();
                           
                     result = s.contains(sSeacch.toLowerCase());
                  }
                  if (result)
                     filteredDeals.add(item);
                  tableView.setItems(filteredDeals);
	            }
	            break;
	         case tblSellers:
               ObservableList<Seller> filteredSellers = FXCollections.observableArrayList();
               for(Seller item : (ObservableList<Seller>)this.tableView.getItems()){
                  boolean result = false;
                  switch (colIdx) {
                     case 1: 
                        result = String.valueOf(item.getId()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 2: 
                        result = String.valueOf(item.toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     default:
                        result = String.valueOf(item.getId().toString() + " " +
                                    item.toString()).toLowerCase()
                                    .contains(sSeacch.toLowerCase());
                        break;
                  }
                  if (result)
                     filteredSellers.add(item);
                  tableView.setItems(filteredSellers);
               }
               break;
	         case tblCustomers:
               ObservableList<Customer> filteredCustomers = FXCollections.observableArrayList();
               for(Customer item : (ObservableList<Customer>)this.tableView.getItems()){
                  boolean result = false;
                  switch (colIdx) {
                     case 1: 
                        result = String.valueOf(item.getId()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 2: 
                        result = String.valueOf(item.toString()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     default:
                        result = String.valueOf(item.getId().toString() + " " +
                                    item.toString()).toLowerCase()
                                    .contains(sSeacch.toLowerCase());
                        break;
                  }
                  if (result)
                     filteredCustomers.add(item);
                  tableView.setItems(filteredCustomers);
               }
               break;
	         case tblPersons:
               ObservableList<Person> filteredPersons = FXCollections.observableArrayList();
               for(Person item : (ObservableList<Person>)this.tableView.getItems()){
                  boolean result = false;
                  switch (colIdx) {
                     case 1: 
                        result = String.valueOf(item.getId()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 2: 
                        result = String.valueOf(item.getSurname()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 3: 
                        result = String.valueOf(item.getName()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 4: 
                        result = String.valueOf(item.getPatron()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     default:
                        result = String.valueOf(item.getId().toString() + " " +
                                    item.getSurname() + " " +
                                    item.getName() + " " +
                                    item.getPatron()).toLowerCase()
                                    .contains(sSeacch.toLowerCase());
                        break;
                  }
                  if (result)
                     filteredPersons.add(item);
                  tableView.setItems(filteredPersons);
               }
               break;
            case tblOrganizations:
               ObservableList<Organization> filteredOrgs = FXCollections.observableArrayList();
               for(Organization item : (ObservableList<Organization>)this.tableView.getItems()){
                  boolean result = false;
                  switch (colIdx) {
                     case 1: 
                        result = String.valueOf(item.getId()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 2: 
                        result = String.valueOf(item.getName()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 3: 
                        result = String.valueOf(item.getInn()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 4: 
                        result = String.valueOf(item.getOgrn()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 5: 
                        result = String.valueOf(item.getKpp()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 6: 
                        result = String.valueOf(item.getOkpo()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     case 7: 
                        result = String.valueOf(item.getAddr()).toLowerCase()
                              .contains(sSeacch.toLowerCase());
                        break;
                     default:
                        result = String.valueOf(item.getId() + " " +
                                    item.getName() + " " +
                                    item.getInn() + " " +
                                    item.getOgrn() + " " +
                                    item.getKpp() + " " +
                                    item.getOkpo() + " " +
                                    item.getAddr()).toLowerCase()
                                    .contains(sSeacch.toLowerCase());
                        break;
                  }
                  if (result)
                     filteredOrgs.add(item);
                  tableView.setItems(filteredOrgs);
               }
               break;
	      }
	   }
	}
	
	
	public void onSearch(ActionEvent actionEvent) {
      filterData(searchField.getText(), this.currentTable, choiceBox
            .getSelectionModel().getSelectedIndex());
  }
	
	public void onDeleteRecord(ActionEvent actionEvent) {
      if (tableView.getSelectionModel().getSelectedIndex() > -1) {
         Alert qMes = new Alert(Alert.AlertType.CONFIRMATION);
         qMes.setTitle(bundle.getString("queryDeleteRecordTitle"));
         qMes.setHeaderText(bundle.getString("queryDeleteRecordHeader"));
         Optional<ButtonType> result;
         switch (this.currentTable) {
            case tblDeals: 
               Deal d = (Deal)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(d.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new DealDao(connection)).deleteById(d.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;
            case tblPersons: 
               Person p = (Person)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(p.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new PersonDao(connection)).deleteById(p.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;
            case tblOrganizations: 
               Organization o = (Organization)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(o.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new OrganizationDao(connection)).deleteById(o.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;
            case tblSellers: 
               Seller s = (Seller)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(s.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new SellerDao(connection)).deleteById(s.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;   
            case tblCustomers: 
               Customer c = (Customer)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(c.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new CustomerDao(connection)).deleteById(c.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;   
            case tblAgents: 
               Agent a = (Agent)tableView.getSelectionModel().getSelectedItem();
               qMes.setContentText(bundle.getString("queryDeleteRecord")+" "+
                              String.valueOf(a.getId())+ "?");
               result = qMes.showAndWait();
               if (result.isPresent() && result.get() == ButtonType.OK) {
                  (new AgentDao(connection)).deleteById(a.getId());
                  tableView.getItems().remove(tableView.getSelectionModel().getSelectedIndex());
               }
               break;   
         }
         
      }
      else {
         Alert infoMes = new Alert(Alert.AlertType.INFORMATION);
         infoMes.setTitle("Information");
         infoMes.setHeaderText("Попытка удаления записи");
         infoMes.setContentText("Ни одна запись в таблице не выделена. Удалить ничего нельзя.");
         infoMes.showAndWait();
      }
   }
	
	public void openRefsPersons(ActionEvent actionEvent) {
      showData(TblTypes.tblPersons);
   }
	
   public void openRefsOrganizations(ActionEvent actionEvent) {
      showData(TblTypes.tblOrganizations);
   }

   public void openTablesDeals(ActionEvent actionEvent) {
      showData(TblTypes.tblDeals);
   }
   
   public void openTablesSellers(ActionEvent actionEvent) {
      showData(TblTypes.tblSellers);
   }
   
   public void openTablesCustomers(ActionEvent actionEvent) {
      showData(TblTypes.tblCustomers);
   }
   
	public void closeApp(ActionEvent actionEvent) {
	   this.window.close();
	}
	
	public void openSettings(ActionEvent actionEvent) {
	   showDialog(DlgTypes.dtSettings);
	}
	
	public void openAbout(ActionEvent actionEvent) {
	   showDialog(DlgTypes.dtAbout);
   }
	
	public void showDialog(DlgTypes dt) {
	   Stage addStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      loader.setResources(bundle);
      switch (dt) {
         case dtSettings:
            loader.setLocation(getClass().getResource("SettingsView.fxml"));
            loader.setControllerFactory(e -> new SettingsController(addStage, bundle));
            addStage.setTitle(bundle.getString("titleDlgSettings"));
            break;
         
         
         default:
            loader.setLocation(getClass().getResource("AboutView.fxml"));
            loader.setControllerFactory(e -> new AboutController(addStage, bundle));
            addStage.setTitle(bundle.getString("titleDlgAbout"));
            break;
      }
      Parent page = null;
      try {
         page = loader.load();
      } catch (IOException e) {
         e.printStackTrace();
      }
      addStage.initModality(Modality.APPLICATION_MODAL);
      addStage.initOwner(window);
      addStage.setResizable(false);
      Scene scene = new Scene(page);
      addStage.setScene(scene);
      addStage.showAndWait();
	}
	
}
