package application;

public enum TblTypes {
   tblPersons,
   tblOrganizations,
   tblAgents,
   tblSellers,
   tblCustomers,
   tblDeals;
}
