package application;
	
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import IntermediaryDB.DBHelper;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
		   prepareSettings();
         Properties p = new Properties();
         p.load(new FileInputStream(new File(getConfigPath(), "application.ini")));
		   Locale l = null;
		   if (p.getProperty("language", "en").toLowerCase().equals("ru"))
		      l = Locale.of("ru", "RU");
		   else
		      l = Locale.of("en", "US");
         ResourceBundle bundle = ResourceBundle
		         .getBundle("bundles.Intermediary", l);
			
		   FXMLLoader loader = new FXMLLoader();
		   loader.setResources(bundle);
		   loader.setLocation(getClass().getResource("MainView.fxml"));
		   loader.setControllerFactory(new Callback<Class<?>, Object>() {
		      Connection c = null;
            @Override
	         public Object call(Class<?> param) {
	            try {
	               c = DBHelper.getInstance(new File(Main.getConfigPath(), "application.ini")).getConnection();
	            } catch (SQLException e) {
	               System.out.println(e.getMessage());
               }
	            return new MainController(primaryStage, bundle, loader, c);
	         }
	      });
		   
		   BorderPane root = (BorderPane)loader.load();
		   Scene scene = new Scene(root,800,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public static void prepareSettings() {
      File settingsFile = new File(getConfigPath(), "application.ini");
      if (!(settingsFile.exists())) {
         try {
            Files.createDirectories(Paths.get(getConfigPath()));
            FileOutputStream fout = new FileOutputStream(settingsFile);
            Properties prop = new Properties();
            prop.setProperty("db", "jdbc:postgresql://185.61.27.15:5432/intermediary");
            prop.setProperty("user", "mediator");
            prop.setProperty("password", "mediator");
            prop.setProperty("language", "ru");
            prop.store(fout, "");
         }
         catch (IOException e) {
            e.printStackTrace();
         }
      }
   }

   public static String getConfigPath()
   {
       String os = System.getProperty("os.name").toLowerCase();

       if (os.contains("win")) {
           return System.getProperty( "user.home" )+"/AppData/Roaming/Intermediary";
       }

       else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
           return System.getProperty( "user.home" )+"/.config/Intermediary";
       }

       return null;
   }
	
}
