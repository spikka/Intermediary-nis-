package application;

import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.stage.Stage;

public class AboutController {
   
   private Stage dialogStage;
   private ResourceBundle bundle;
   
   
   public AboutController(Stage window, ResourceBundle bundle) {
      this.dialogStage = window;
      this.bundle = bundle;
   }
   
   @FXML 
   public void closeAboutDlg() {
      this.dialogStage.close();
   }
}
