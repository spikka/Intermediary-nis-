package application;
public enum DlgTypes {
   dtSettings,
   dtAbout;
}
