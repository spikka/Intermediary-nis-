package application;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.util.Properties;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SettingsController {
   
   @FXML private TextField tfDb;
   @FXML private TextField tfUsername;
   @FXML private TextField tfPassword;
   @FXML private ComboBox<String> cbLanguage;
   
   private Stage dialogStage;
   private ResourceBundle bundle;
   
   
   public SettingsController(Stage window, ResourceBundle bundle) {
      this.dialogStage = window;
      this.bundle = bundle;
   }
   
   public void initialize() {
      ObservableList<String> langs = FXCollections.observableArrayList(this.bundle.getString("langsImemEn"), this.bundle.getString("langsImemRu"));
      cbLanguage.getItems().setAll(langs);
      try {
         Properties prop = new Properties();
         prop.load(new FileInputStream(new File(Main.getConfigPath(), "application.ini")));
         this.tfDb.setText(prop.getProperty("db"));
         this.tfUsername.setText(prop.getProperty("user"));
         this.tfPassword.setText(prop.getProperty("password"));
         if (prop.getProperty("language", "en").toLowerCase().equals("ru"))
            cbLanguage.getSelectionModel().select(1);
         else
            cbLanguage.getSelectionModel().select(0); 
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
      }
   }

   public String getDb() {
      return tfDb.getText();
   }

   public String getUsername() {
      return tfUsername.getText();
   }

   public String getPassword() {
      return tfPassword.getText();
   }

   public String getLanguage() {
      return cbLanguage.getValue();
   }

   
   @FXML 
   public void closeSettingsDlg() {
      this.dialogStage.close();
   }

   @FXML 
   public void saveSettings() {
      try {
         Properties prop = new Properties();
         //
         prop.setProperty("db", getDb());
         prop.setProperty("user", getUsername());
         prop.setProperty("password", getPassword());
         if (cbLanguage.getValue().toLowerCase().equals("russian"))
            prop.setProperty("language", "ru");
         else
            prop.setProperty("language", "en");
         prop.store(new FileOutputStream(new File(Main.getConfigPath(), "application.ini")), "");
         this.dialogStage.close();
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
      }
   }
}
