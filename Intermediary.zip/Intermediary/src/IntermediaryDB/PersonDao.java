package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PersonDao implements Dao<Person, Integer> {
   private Connection dbConnect;
   private final static String FIND_ALL = "SELECT * FROM persons";
   private final static String FIND_BY_ID = "SELECT * FROM persons WHERE id = ?";
   private final static String DEL_BY_ID = "DELETE FROM persons WHERE id = ?";
   private final static String INS_PERSON = "insert into persons (surname, name, patron) values (?, ?, ?) RETURNING id";
   private final static String UPD_PERSON = "UPDATE persons SET surname = ?, name = ?, patron = ? WHERE id = ?";
      
   protected List<Person> mapper(ResultSet rs) {
      List<Person> list = new ArrayList<>();
      try {
          while (rs.next()) {
              list.add(new Person(
                      rs.getInt("id"),
                      rs.getString("surname"),
                      rs.getString("name"),
                      rs.getString("patron")
              ));
          }
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
  }
   public PersonDao(Connection conn) {
      this.dbConnect = conn;
   }
   @Override
   public Person findById(Integer id) {
      List<Person> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Person> findAll() {
      List<Person> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Person save(Person entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     }
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_PERSON)) {
         statement.setObject(1, entity.getSurname());
         statement.setObject(2, entity.getName());
         statement.setObject(3, entity.getPatron());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Person update(Person entity) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(UPD_PERSON)) {
         statement.setObject(1, entity.getSurname());
         statement.setObject(2, entity.getName());
         statement.setObject(3, entity.getPatron());
         statement.setObject(4, entity.getId());
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
      return entity;
   }

   @Override
   public void delete(Person entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
