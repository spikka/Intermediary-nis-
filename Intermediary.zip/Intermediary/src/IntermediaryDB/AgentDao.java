package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgentDao implements Dao<Agent, Integer> {

   private Connection dbConnect;
   private PersonDao personDao;
   private OrganizationDao organizationDao;
   private final static String FIND_ALL = "SELECT * FROM agents";
   private final static String FIND_BY_ID = "SELECT * FROM agents WHERE id = ?";
   private final static String DEL_BY_ID = "DELETE FROM agents WHERE id = ?";
   private final static String INS_AGENT = "insert into agents (id_persons, id_organizations) values (?, ?) RETURNING id";
   private final static String UPD_AGENT = "UPDATE agents SET id_persons = ?, id_organizations = ? WHERE id = ?";
   
   public AgentDao(Connection conn) {
      this.dbConnect = conn;
      this.personDao = new PersonDao(conn);
      this.organizationDao = new OrganizationDao(conn);
   }
   
   protected List<Agent> mapper(ResultSet rs) {
      List<Agent> list = new ArrayList<>();
      try {
          while (rs.next()) {
              list.add(new Agent(
                      rs.getInt("id"),
                      this.personDao.findById(rs.getInt("id_persons")),
                      this.organizationDao.findById(rs.getInt("id_organizations"))
              ));
          }
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
  }

   @Override
   public Agent findById(Integer id) {
      List<Agent> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Agent> findAll() {
      List<Agent> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
         e.printStackTrace();
          //System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Agent save(Agent entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     }
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_AGENT)) {
         statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
         statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Agent update(Agent entity) {
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(UPD_AGENT)) {
          statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
          statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
          statement.setObject(3, entity.getId());
          statement.executeUpdate();
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return  entity;
   }

   @Override
   public void delete(Agent entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
