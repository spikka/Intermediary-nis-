package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDao implements Dao<Customer, Integer> {

   private Connection dbConnect;
   private PersonDao personDao;
   private OrganizationDao organizationDao;
   private final static String FIND_ALL = "SELECT * FROM customers";
   private final static String FIND_BY_ID = "SELECT * FROM customers WHERE id = ?";
   private final static String DEL_BY_ID = "DELETE FROM customers WHERE id = ?";
   private final static String INS_CUSTOMERS = "insert into customers (id_persons, id_organizations) values (?, ?) RETURNING id";
   private final static String UPD_CUSTOMERS = "UPDATE customers SET id_persons = ?, id_organizations = ? WHERE id = ?";
   
   public CustomerDao(Connection conn) {
      this.dbConnect = conn;
      this.personDao = new PersonDao(conn);
      this.organizationDao = new OrganizationDao(conn);
   }
   
   protected List<Customer> mapper(ResultSet rs) {
      List<Customer> list = new ArrayList<>();
      try {
          while (rs.next()) {
              list.add(new Customer(
                      rs.getInt("id"),
                      this.personDao.findById(rs.getInt("id_persons")),
                      this.organizationDao.findById(rs.getInt("id_organizations"))
              ));
          }
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
  }

   @Override
   public Customer findById(Integer id) {
      List<Customer> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Customer> findAll() {
      List<Customer> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Customer save(Customer entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     }
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_CUSTOMERS)) {
         statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
         statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Customer update(Customer entity) {
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(UPD_CUSTOMERS)) {
          statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
          statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
          statement.setObject(3, entity.getId());
          statement.executeUpdate();
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return  entity;
   }

   @Override
   public void delete(Customer entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
