package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SellerDao implements Dao<Seller, Integer> {
   
   private Connection dbConnect;
   private PersonDao personDao;
   private OrganizationDao organizationDao;
   private final static String FIND_ALL = "SELECT * FROM sellers";
   private final static String FIND_BY_ID = "SELECT * FROM sellers WHERE id = ?";
   private final static String DEL_BY_ID = "DELETE FROM sellers WHERE id = ?";
   private final static String INS_SELLER = "insert into sellers (id_persons, id_organizations) values (?, ?) RETURNING id";
   private final static String UPD_SELLER = "UPDATE sellers SET id_persons = ?, id_organizations = ? WHERE id = ?";
   
   public SellerDao(Connection conn) {
      this.dbConnect = conn;
      this.personDao = new PersonDao(conn);
      this.organizationDao = new OrganizationDao(conn);
   }
   
   protected List<Seller> mapper(ResultSet rs) {
      List<Seller> list = new ArrayList<>();
      try {
          while (rs.next()) {
              list.add(new Seller(
                      rs.getInt("id"),
                      this.personDao.findById(rs.getInt("id_persons")),
                      this.organizationDao.findById(rs.getInt("id_organizations"))
              ));
          }
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
  }

   @Override
   public Seller findById(Integer id) {
      List<Seller> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Seller> findAll() {
      List<Seller> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Seller save(Seller entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     }
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_SELLER)) {
         statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
         statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Seller update(Seller entity) {
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(UPD_SELLER)) {
          statement.setObject(1, this.personDao.save(entity.getPerson()).getId());
          statement.setObject(2, this.organizationDao.save(entity.getOrganization()).getId());
          statement.setObject(3, entity.getId());
          statement.executeUpdate();
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return  entity;
   }

   @Override
   public void delete(Seller entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
