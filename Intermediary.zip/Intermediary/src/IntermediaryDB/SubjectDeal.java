package IntermediaryDB;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

public abstract class SubjectDeal {
   
   private IntegerProperty id;
   private ObjectProperty<Person> person;
   private ObjectProperty<Organization> organization;

   public SubjectDeal(Integer id, Person p, Organization o) {
      this.id = new SimpleIntegerProperty(id);
      this.person = new SimpleObjectProperty<Person>(p);
      this.organization = new SimpleObjectProperty<Organization>(o);
   }
   public SubjectDeal() {
      this(0, null, null);
   }
   
   public IntegerProperty idProperty() {
      return id;
   }
   
   public ObjectProperty<Person> personProperty() {
      return person;
   }
   
   public ObjectProperty<Organization> organizationProperty() {
      return organization;
   }

   public Integer getId() {
      return id.get();
   }

   public void setId(Integer id) {
      this.id.set(id);
   }

   public Person getPerson() {
      return person.get();
   }

   public void setPerson(Person person) {
      this.person.set(person);
   }

   public Organization getOrganization() {
      return organization.get();
   }

   public void setOrganization(Organization organization) {
      this.organization.set(organization);
   }

}
