package IntermediaryDB;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Person {
   private IntegerProperty id;
   private StringProperty surname;
   private StringProperty name;
   private StringProperty patron;
   
   public Person(Integer id, String surname, String name, String patron) {
      this.id = new SimpleIntegerProperty(id);
      this.surname = new SimpleStringProperty(surname);
      this.name = new SimpleStringProperty(name);
      this.patron = new SimpleStringProperty(patron);
   }
   public Person() {
      this(0, "", "", "");
   }
   
   @Override
   public String toString() {
      return this.getSurname()+" "+this.getName().charAt(0)+"."+this.getPatron().charAt(0)+".";
   }
   
   public IntegerProperty idProperty() { return id; }
   public StringProperty surnameProperty() { return surname; }
   public StringProperty nameProperty() { return name; }
   public StringProperty patronProperty() { return patron; }
      
   public Integer getId() {
      return id.get();
   }
   public void setId(Integer id) {
      this.id.set(id);
   }
   public String getSurname() {
      return surname.get();
   }
   public void setSurname(String surname) {
      this.surname.set(surname);
   }
   public String getName() {
      return name.get();
   }
   public void setName(String name) {
      this.name.set(name);
   }
   public String getPatron() {
      return patron.get();
   }
   public void setPatron(String patron) {
      this.patron.set(patron);
   }

}
