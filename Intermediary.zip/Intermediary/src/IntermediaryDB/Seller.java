package IntermediaryDB;

public class Seller extends SubjectDeal {
   // В общем и целом можно было и не
   // плодить сущности, но... Может потребоваться!
   
   public Seller(Integer id, Person p, Organization o) {
      super(id, p, o);
   }
   public Seller() {
      super();
   }
   
   @Override
   public String toString() {
      if (this.getOrganization().getId() > 0)
         return this.getOrganization().getName() + " (ИНН: " +
            this.getOrganization().getInn() + ", отв.лицо: " +
            this.getPerson().toString() +")";
      else
         return this.getPerson().toString() +" (ФЛ)";
   }
}
