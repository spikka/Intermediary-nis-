package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DealDao implements Dao<Deal, Integer> {

   private Connection dbConnect;
   private AgentDao agentDao;
   private SellerDao sellerDao;
   private CustomerDao customerDao;
   private final static String FIND_ALL = "SELECT * FROM deals WHERE id > 0";
   private final static String FIND_BY_ID = "SELECT * FROM deals WHERE id = ?";
   private final static String DEL_BY_ID = "DELETE FROM deals WHERE id = ?";
   private final static String INS_DEAL = "insert into deals (id_agents, id_sellers, id_customers, bargain, date_d, sum_d, profit) values (?, ?, ?, ?, ?, ?, ?) RETURNING id";
   private final static String UPD_DEAL = "UPDATE deals SET id_agents = ?, id_sellers = ?, id_customers = ?, bargain = ?, date_d = ?, sum_d = ?, profit = ? WHERE id = ?";
   
   protected List<Deal> mapper(ResultSet rs) {
      List<Deal> list = new ArrayList<>();
      try {
          while (rs.next()) {
              list.add(new Deal(
                      rs.getInt("id"),
                      this.agentDao.findById(rs.getInt("id_agents")),
                      this.sellerDao.findById(rs.getInt("id_sellers")),
                      this.customerDao.findById(rs.getInt("id_customers")),
                      rs.getString("bargain"),
                      rs.getDate("date_d"),
                      rs.getBigDecimal("sum_d"),
                      rs.getBigDecimal("profit")
              ));
          }
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
  }
   
   public DealDao(Connection conn) {
      this.dbConnect = conn;
      this.agentDao = new AgentDao(conn);
      this.sellerDao = new SellerDao(conn);
      this.customerDao = new CustomerDao(conn);
   }
   
   @Override
   public Deal findById(Integer id) {
      List<Deal> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Deal> findAll() {
      List<Deal> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Deal save(Deal entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     } 
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_DEAL)) {
         statement.setObject(1, entity.getAgent().getId());
         statement.setObject(2, entity.getSeller().getId());
         statement.setObject(3, entity.getCustomer().getId());
         statement.setObject(4, entity.getBargain());
         statement.setObject(5, entity.getDate_d());
         statement.setObject(6, entity.getSum_d());
         statement.setObject(7, entity.getProfit());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Deal update(Deal entity) {
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(UPD_DEAL)) {
          statement.setObject(1, entity.getAgent().getId());
          statement.setObject(2, entity.getSeller().getId());
          statement.setObject(3, entity.getCustomer().getId());
          statement.setObject(4, entity.getBargain());
          statement.setObject(5, entity.getDate_d());
          statement.setObject(6, entity.getSum_d());
          statement.setObject(7, entity.getProfit());
          statement.setObject(8, entity.getId());
          statement.executeUpdate();
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return  entity;
   }

   @Override
   public void delete(Deal entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
