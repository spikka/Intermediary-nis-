package IntermediaryDB;

import org.postgresql.Driver;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBHelper {
   private String db;
   private String user;
   private String password;
   
   private Connection connection = null;
   private static DBHelper instance = null;
   
   public static synchronized DBHelper getInstance(File fileProp){
      if (instance == null)
         instance = new DBHelper(fileProp);
      return instance;
   }
   
   private DBHelper(File fileProp) {
      try {
         Properties prop = new Properties();
         prop.load(new FileInputStream(fileProp));
         this.db = prop.getProperty("db");
         this.user = prop.getProperty("user");
         this.password = prop.getProperty("password");
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
      }
   }
   
   public Connection getConnection() throws SQLException{
      if (this.connection == null) {
         try {
            DriverManager.registerDriver(new Driver());
            this.connection = DriverManager.getConnection(this.getDb(), 
                       this.getUser(), this.getPassword());
         }
         catch (SQLException e) {
            System.out.println(e.getMessage());
         }
      }
      return this.connection;
   } 
   
   public String getDb() {
      return this.db;
   }
   public String getUser() {
      return this.user;
   }
   public String getPassword() {
      return this.password;
   }
}
