package IntermediaryDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrganizationDao implements Dao<Organization, Integer> {
    private Connection dbConnect;
    private final static String FIND_ALL = "SELECT * FROM organizations WHERE id > 0";
    private final static String FIND_BY_ID = "SELECT * FROM organizations WHERE id = ?";
    private final static String DEL_BY_ID = "DELETE FROM organizations WHERE id = ?";
    private final static String INS_ORGANIZATION = "insert into organizations (name, inn, ogrn, kpp, okpo, addr) values (?, ?, ?, ?, ?, ?) RETURNING id";
    private final static String UPD_ORGANIZATION = "UPDATE organizations SET name = ?, inn = ?, ogrn = ?, kpp = ?, okpo = ?, addr = ? WHERE id = ?";
    
    protected List<Organization> mapper(ResultSet rs) {
       List<Organization> list = new ArrayList<>();
       try {
           while (rs.next()) {
               list.add(new Organization(
                       rs.getInt("id"),
                       rs.getString("name"),
                       rs.getString("inn"),
                       rs.getString("ogrn"),
                       rs.getString("kpp"),
                       rs.getString("okpo"),
                       rs.getString("addr")
               ));
           }
       } catch (SQLException e) {
           System.out.println(e.getMessage());
       }
       return list;
   }
   public OrganizationDao(Connection conn) {
      this.dbConnect = conn;
   }
   @Override
   public Organization findById(Integer id) {
      List<Organization> list = null;
      try(PreparedStatement statement =
                  this.dbConnect
                          .prepareStatement(FIND_BY_ID)) {
          statement.setObject(1, id);
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      if (list != null)
         return list.get(0);
      else
          return null;
   }

   @Override
   public List<Organization> findAll() {
      List<Organization> list = null;
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(FIND_ALL)) {
          ResultSet rs = statement.executeQuery();
          list = mapper(rs);
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return list;
   }

   @Override
   public Organization save(Organization entity) {
      if (entity.getId()>0) {
         return this.update(entity);
     } else if (entity.getId() == -1)
     try(PreparedStatement statement =
           this.dbConnect
                         .prepareStatement(INS_ORGANIZATION)) {
         statement.setObject(1, entity.getName());
         statement.setObject(2, entity.getInn());
         statement.setObject(3, entity.getOgrn());
         statement.setObject(4, entity.getKpp());
         statement.setObject(5, entity.getOkpo());
         statement.setObject(6, entity.getAddr());
         ResultSet rs = statement.executeQuery();
         entity.setId(rs.getInt("id"));
     } catch (SQLException e) {
         System.out.println(e.getMessage());
     }
     return  entity;
   }

   @Override
   public Organization update(Organization entity) {
      try(PreparedStatement statement =
            this.dbConnect
                          .prepareStatement(UPD_ORGANIZATION)) {
          statement.setObject(1, entity.getName());
          statement.setObject(2, entity.getInn());
          statement.setObject(3, entity.getOgrn());
          statement.setObject(4, entity.getKpp());
          statement.setObject(5, entity.getOkpo());
          statement.setObject(6, entity.getAddr());
          statement.setObject(7, entity.getId());
          statement.executeUpdate();
      } catch (SQLException e) {
          System.out.println(e.getMessage());
      }
      return  entity;
   }

   @Override
   public void delete(Organization entity) {
      this.deleteById(entity.getId());
   }

   @Override
   public void deleteById(Integer id) {
      try(PreparedStatement statement =
            this.dbConnect
                    .prepareStatement(DEL_BY_ID)) {
         statement.setObject(1, id);
         statement.executeUpdate();
      } catch (SQLException e) {
         System.out.println(e.getMessage());
      }
   }

}
