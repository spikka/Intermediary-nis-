package IntermediaryDB;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Organization {
   private IntegerProperty id;
   private StringProperty name;
   private StringProperty inn;
   private StringProperty ogrn;
   private StringProperty kpp;
   private StringProperty okpo;
   private StringProperty addr;
   
   
   
   public Organization(Integer id, String name, String inn, String ogrn,
         String kpp, String okpo, String addr) {
      this.id = new SimpleIntegerProperty(id);
      this.name = new SimpleStringProperty(name);
      this.inn = new SimpleStringProperty(inn);
      this.ogrn = new SimpleStringProperty(ogrn);
      this.kpp = new SimpleStringProperty(kpp);
      this.okpo = new SimpleStringProperty(okpo);
      this.addr = new SimpleStringProperty(addr);
   }

   public Organization() {
      //Идентификатор -1 - внутренняя константа, именно, 
      //для новой строки в таблице (просто договоримся об этом).
      //Запись с идентификатором 0 должна быть для организации 
      // "Физические лица"
      this(-1, "", "", "", "", "", "");
   }

   public IntegerProperty idProperty() {
      return this.id;
   }
   
   public int getId() {
      return this.idProperty().get();
   }
   
   public void setId(final int id) {
      this.idProperty().set(id);
   }

   public StringProperty nameProperty() {
      return this.name;
   }
   

   public String getName() {
      return this.nameProperty().get();
   }
   

   public void setName(final String name) {
      this.nameProperty().set(name);
   }
   

   public StringProperty innProperty() {
      return this.inn;
   }
   

   public String getInn() {
      return this.innProperty().get();
   }
   

   public void setInn(final String inn) {
      this.innProperty().set(inn);
   }
   

   public StringProperty ogrnProperty() {
      return this.ogrn;
   }
   

   public String getOgrn() {
      return this.ogrnProperty().get();
   }
   

   public void setOgrn(final String ogrn) {
      this.ogrnProperty().set(ogrn);
   }
   

   public StringProperty kppProperty() {
      return this.kpp;
   }
   

   public String getKpp() {
      return this.kppProperty().get();
   }
   

   public void setKpp(final String kpp) {
      this.kppProperty().set(kpp);
   }
   

   public StringProperty okpoProperty() {
      return this.okpo;
   }
   

   public String getOkpo() {
      return this.okpoProperty().get();
   }
   

   public void setOkpo(final String okpo) {
      this.okpoProperty().set(okpo);
   }
   

   public StringProperty addrProperty() {
      return this.addr;
   }
   

   public String getAddr() {
      return this.addrProperty().get();
   }
   

   public void setAddr(final String addr) {
      this.addrProperty().set(addr);
   }   
   
}
