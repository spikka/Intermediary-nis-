package IntermediaryDB;

public class Agent extends SubjectDeal {
   // В общем и целом можно было и не
   // плодить сущности, но... Может потребоваться!
   public Agent(Integer id, Person p, Organization o) {
      super(id, p, o);
   }
   public Agent() {
      super();
   }
   @Override
   public String toString() {
      return this.getOrganization().getName() + " (ИНН: " +
            this.getOrganization().getInn() + ", отв.лицо: " +
            this.getPerson().toString() +")";
   }
}
