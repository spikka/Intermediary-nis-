package IntermediaryDB;

import java.math.BigDecimal;
import java.util.Date;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Deal {

   private IntegerProperty id;
   private ObjectProperty<Agent> agent;
   private ObjectProperty<Seller> seller;
   private ObjectProperty<Customer> customer;
   private StringProperty bargain;
   private ObjectProperty<Date> date_d;
   private ObjectProperty<BigDecimal> sum_d;
   private ObjectProperty<BigDecimal> profit;
   
   public Deal(Integer id, Agent a, Seller s, Customer c, String bargain,
               Date dd, BigDecimal sd, BigDecimal p) {
      this.id = new SimpleIntegerProperty(id);
      this.agent = new SimpleObjectProperty<Agent>(a);
      this.seller = new SimpleObjectProperty<Seller>(s);
      this.customer = new SimpleObjectProperty<Customer>(c);
      this.bargain = new SimpleStringProperty(bargain);
      this.date_d = new SimpleObjectProperty<Date>(dd);
      this.sum_d = new SimpleObjectProperty<BigDecimal>(sd);
      this.profit = new SimpleObjectProperty<BigDecimal>(p);
   }
   
   public Deal() {
      this(0, null, null, null, "", null, null, null);
   }
   
   public IntegerProperty idProperty() {
      return this.id;
   }
   
   public int getId() {
      return this.idProperty().get();
   }
   
   public void setId(final int id) {
      this.idProperty().set(id);
   }
   
   public ObjectProperty<Agent> agentProperty() {
      return this.agent;
   }
   
   public Agent getAgent() {
      return this.agentProperty().get();
   }
   
   public void setAgent(final Agent agent) {
      this.agentProperty().set(agent);
   }
   
   public ObjectProperty<Seller> sellerProperty() {
      return this.seller;
   }
   
   public Seller getSeller() {
      return this.sellerProperty().get();
   }
   
   public void setSeller(final Seller seller) {
      this.sellerProperty().set(seller);
   }
   
   public ObjectProperty<Customer> customerProperty() {
      return this.customer;
   }
   
   public Customer getCustomer() {
      return this.customerProperty().get();
   }
   
   public void setCustomer(final Customer customer) {
      this.customerProperty().set(customer);
   }
   
   public StringProperty bargainProperty() {
      return this.bargain;
   }
   
   public String getBargain() {
      return this.bargainProperty().get();
   }
   
   public void setBargain(final String bargain) {
      this.bargainProperty().set(bargain);
   }
   
   public ObjectProperty<Date> date_dProperty() {
      return this.date_d;
   }
   
   public Date getDate_d() {
      return this.date_dProperty().get();
   }
   
   public void setDate_d(final Date date_d) {
      this.date_dProperty().set(date_d);
   }
   
   public ObjectProperty<BigDecimal> sum_dProperty() {
      return this.sum_d;
   }
   
   public BigDecimal getSum_d() {
      return this.sum_dProperty().get();
   }
   
   public void setSum_d(final BigDecimal sum_d) {
      this.sum_dProperty().set(sum_d);
   }
   
   public ObjectProperty<BigDecimal> profitProperty() {
      return this.profit;
   }
   
   public BigDecimal getProfit() {
      return this.profitProperty().get();
   }
   
   public void setProfit(final BigDecimal profit) {
      this.profitProperty().set(profit);
   }
   

}
